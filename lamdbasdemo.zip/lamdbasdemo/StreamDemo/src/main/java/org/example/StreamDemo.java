package org.example;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class StreamDemo {

    public static void main(String[] args) {
        List<Product> productList = new ArrayList<>();

        productList.add(new Product(1,"Laptop",25000f));
        productList.add(new Product(2,"TV",30000f));
        productList.add(new Product(3,"Music",25000f));
        productList.add(new Product(4,"Laptop",400000f));
        productList.add(new Product(5,"Smart TV",30000f));


        productList.stream()
                .filter(product -> product.price>25000)//filtering the product
                 .map(product -> product.price) //fetching the price
                .forEach(System.out::println);//printing of price

//store the price in some other list
       List<Float> priceList = productList.stream()
                .filter(product -> product.price>25000)//filtering the product
                .map(product -> product.price) //fetching the price
                .collect(Collectors.toList());

        System.out.println(priceList);


        //get Product name

     productList.stream()
                .map(product -> product.getName())
                .collect(Collectors.toList())
             .forEach(System.out::println);

     //Lets do some sorting

        //1) sorting on name - 2) sorting on price

        System.out.println("Sorting on basis of name");

        productList.stream()
                .sorted(Comparator.comparing(Product::getName).thenComparing(Product::getPrice))
                .collect(Collectors.toList())
                .forEach(System.out::println);

        //Check all products price is greater than 25k methods anymatch or nonematch allmatch

       boolean status =  productList.stream()
                .anyMatch(product -> product.getPrice()>25000);

        System.out.println(status);

        System.out.println("---Max price-----");

        productList.stream()
                .max(Comparator.comparing(Product::getPrice))
                .ifPresent(System.out::println);

        System.out.println("---Min price-----");

        productList.stream()
                .min(Comparator.comparing(Product::getPrice))
                .ifPresent(System.out::println);

        System.out.println("Grouping demo-------------");

        Map<String,List<Product>> groupByName = productList.stream()
                .collect(Collectors.groupingBy(Product::getName));

        groupByName.forEach((name,product) ->{
            System.out.println(name);
            product.forEach(System.out::println);
            System.out.println();
        });

        System.out.println("-----------------");
        productList.stream()
                .filter(product -> product.getName().equals("Laptop"))
                .max(Comparator.comparing(Product::getPrice))
                .ifPresent(System.out::println);







    }
}

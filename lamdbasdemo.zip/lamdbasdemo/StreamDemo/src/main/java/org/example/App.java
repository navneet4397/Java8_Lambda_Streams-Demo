package org.example;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {

        List<Integer> number = Arrays.asList(1,2,3,4,5,6,7,8,9,10);
        System.out.println(getSumOfEvenNumbers(number));
        System.out.println(getSumOfEvenNumbersByStreams(number));

    }
    //Prior to java 8
    public static int getSumOfEvenNumbers(List<Integer> number){

        Iterator<Integer> iterator = number.iterator();
        int sum=0;
        while(iterator.hasNext()){
            int num = iterator.next();
            if(num%2 ==0){
                sum+=num;
            }
        }
        return sum;
    }

    public static int getSumOfEvenNumbersByStreams(List<Integer> number) {

        return number.stream()
                .filter(num -> num%2 ==0)
                .mapToInt(value -> value)
                .sum();


    }

}

package org.example;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.function.Predicate;

/**
 * Hello world!
 *
 */
public class App
{
    public static void main( String[] args )
    {
           List<String> countries = Arrays.asList("India","USA","Britain","France","Italy","Ireland");
           for (String str : countries){
              // System.out.println(str);
           }

       // System.out.println("--- Lambda output----");
          // countries.forEach(country -> System.out.println(country));

       // System.out.println("---------------");
         //  countries.forEach(System.out::println);

        //Show all contries
      filter(countries,c -> true);

           //show none of the countries
        filter(countries,c->false);

        System.out.println("--------");
        //show all countries name ends with a
        filter(countries,c-> c.endsWith("a"));

        System.out.println("--------");
        //show all countries name starts with I
        filter(countries,c-> c.startsWith("I"));

        //show all countries where length is greater than 6
        System.out.println("--------");
        filter(countries , c->c.length()>=6);

    }

    public static void filter(List<String> countries, Predicate<String> condition){
            for (String country: countries){
                if(condition.test(country)){
                 //   System.out.println(country);
                }
            }


        System.out.println("___________________");




            Employee emp1 = new Employee(1,"John",100000,"IT");
        Employee emp2 = new Employee(2,"Johny",20000,"Marketing");
        Employee emp3 = new Employee(3,"Harry",500000,"Sales");
        Employee emp4 = new Employee(4,"Judith",300000,"Account");

        List<Employee> employeeList = Arrays.asList(emp1,emp2,emp3,emp4);

        Comparator<Employee> comparator = new Comparator<Employee>() {
            @Override
            public int compare(Employee e1, Employee e2) {
                return e2.getEmpId()-e1.getEmpId();
            }
        };

        Collections.sort(employeeList,comparator);
        System.out.println(employeeList);




    }



}

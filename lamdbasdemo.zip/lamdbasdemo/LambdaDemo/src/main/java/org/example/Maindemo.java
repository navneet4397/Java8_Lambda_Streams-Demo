package org.example;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Maindemo {

    public static void main(String[] args) {

        Employee emp1 = new Employee(1,"John",100000,"IT");
        Employee emp2 = new Employee(2,"Johny",20000,"Marketing");
        Employee emp3 = new Employee(3,"Harry",500000,"Sales");
        Employee emp4 = new Employee(4,"Judith",300000,"Account");

        List<Employee> employeeList = Arrays.asList(emp1,emp2,emp3,emp4);
//prior to 8
        Comparator<Employee> comparator = new Comparator<Employee>() {
            @Override
            public int compare(Employee e1, Employee e2) {
                return e2.getEmpId()-e1.getEmpId();
            }
        };

        Collections.sort(employeeList,comparator);
        System.out.println(employeeList);

        //with java 8

        Comparator<Employee> comparator1 = (Employee e1,Employee e2)->(e1.getName().compareTo(e2.getName()));
        Collections.sort(employeeList,comparator1);
        System.out.println(employeeList);

        Collections.sort(employeeList,(Employee e1,Employee e2)->(int)(e1.getSalary()-e2.getSalary()));
        System.out.println(employeeList);

        Collections.sort(employeeList,(e1,e2)->(int)(e1.getDepartment().compareTo(e2.getDepartment())));
        System.out.println(employeeList);


    }
}

package org.example;

import java.util.*;

public class LambdaDemo {
    public static void main(String[] args) {
        Employee emp1 = new Employee(1,"John",10001,"IT");
        Employee emp2 = new Employee(2,"Johny",40000,"Marketing");
        Employee emp3 = new Employee(3,"Harry",50000,"Sales");
        Employee emp4 = new Employee(4,"Judith",20000,"Accounts");

        List<Employee> employeeList = Arrays.asList(emp1,emp2,emp3,emp4);

        Comparator<Employee> comparator = new Comparator<Employee>() {
            @Override
            public int compare(Employee e1, Employee e2) {
                return e2.getEmpId()-e1.getEmpId();
            }
        };

        Collections.sort(employeeList,comparator);
        System.out.println(employeeList);

        Comparator <Employee>comparator1 = (Employee e1 , Employee e2) ->(int)(e1.getName().compareTo(e2.getName()));

        Collections.sort(employeeList, comparator1);
        System.out.println(employeeList);

        System.out.println("Sort by salary");
        Collections.sort(employeeList,(Employee e1 , Employee e2) ->(int)(e1.getSalary()-(e2.getSalary())));
        System.out.println(employeeList);
        Collections.sort(employeeList,( e1,e2) ->(int)(e1.getSalary()-(e2.getSalary())));

    }

}

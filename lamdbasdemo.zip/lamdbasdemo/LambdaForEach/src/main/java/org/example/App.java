package org.example;

import java.sql.SQLOutput;
import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
           List<String> countries = Arrays.asList("India","USA", "Britain","France","Italy","Ireland");

        for (String c: countries
             ) {
            System.out.println(c);
        }

        System.out.println("----------------------");
        // Java 8 using lambda

        countries.forEach(c -> System.out.println(c));

        //Java 8 onwards , using method refernce
        System.out.println("----------------------");
        countries.forEach(System.out::println);
        // now lest see predicate in java8 . write the method filter first than call the method

        System.out.println("Show all countries");
        filter(countries,c-> true);
        System.out.println("Show none all the countries");
        filter(countries,c-> false);
        System.out.println("Show all the countries ends with a");
        filter(countries,c-> c.endsWith("a"));
        System.out.println("Show all the countries starts with I");
        filter(countries,c-> c.startsWith("I"));
        System.out.println("Show all the countries length more than 6");
        filter(countries,c-> c.length()>=6);

    }

    public static void filter(List<String> countries , Predicate<String> condition){
        for (String country : countries){
            if(condition.test(country))
            {
                System.out.println(country);
            }
        }
    }
}
